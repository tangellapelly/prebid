describe('adLoader', function () {
  var assert = require('chai').assert,
    adLoader = require('../../src/adloader');
});
